package operadores;

public class Respuesta {
	private int id;
	private String enunciado;
	private boolean esUtil;



	public String[] respuestasPrograma() {
		String[] respuestaPrograma = {
"0. Todas las técnicas laborales ofertadas por Cesde, que son un total de 33 programas. En www.cesde.edu.co podrás familiarizarte con la oferta académica y las sedes donde se pueden estudiar.", 
"1. La oferta es amplia, pueden acceder tanto a educación técnica como a programas de educación continua tales como cursos y diplomados.", 
"3. Ofrece Selección o formación por destrezas para empresas o personas cesantes identificando los procesos a potencializar para obtener resultados eficaces en el menor tiempo posible.",
"4. Aplica para empresas afiliadas y no afiliadas a Comfama ",

"5. Empresas afiliadas a Comfama: La Caja asume el costo de la formación a través de los recursos del proyecto Ley de emprendimiento, para este caso la empresa debe garantizar la contratación de las personas que desea formar."
+ "Empresas no afiliadas a Comfama: la empresa que solicita el servicio realizará el pago de manera particular.",

"6. Su formación es de carácter intensivo enfocados en cursos que permiten la potencialización de conocimientos y habilidades de los empleados o personas naturales cesantes en busca de un empleo según sus capacidades.",

"7. Las mujeres deben ser mayores de 16 años, sin límite de edad.\r\n"
+ "Hombres entre los 16 y 28 años."
+ "Formación académica a partir de bachillerato hasta posgrado."
+ "Estar desempleado o en búsqueda de su primer empleo."
+ "Vivir en Antioquia. Para habitantes del Valle de Aburrá, residir en estratos 1, 2, 3 o 4."
+ "Querer estudiar o trabajar en uno de los sectores donde el programa tiene oportunidades laborales."
+ "Los participantes no deben ser beneficiarios de otras becas de estudio."
		};
		return respuestaPrograma;
	}
	
	public String[]  respuestasSedes() {
		String[] respuestaSede = { "0. Si, contamos con sede en Medellín, Bello, Rionegro, Apartadó, La Pintada y Bogotá. Se debe tener en cuenta la oferta de cada sede."
		};
		return respuestaSede;
	}
	
    public String[] respuestasBeneficio() {
    	String[] respuestaBeneficio = {"0. Si, aplica para formación de extensión. El descuento es de acuerdo con la categoría de afiliación a Comfama.",
    			
    			"1. Afiliados empleados: trabajadores activos afiliados a Comfama por medio de su vinculación como colaborador en una empresa"
    			+""
    			+ "Afiliado beneficiarios: cónyuges e hijos de trabajadores activos afiliados a Comfama"
    			+ ""
    			+ "Jóvenes afiliados: hijos entre 16 y 23 años de trabajadores activos afiliados a Comfama ",
    			
    			"2. La formación es 100% paga por Comfama. En caso de que deserte del programa deberá pagarle a la Caja el 50% de la formación.",
    			"3. "
    	};
    	return respuestaBeneficio ;
    }
    
    public String[] respuestasIncripciones() {
    	String[] respuestaIncripciones = {"0. Formación para empleados: https://tiendaempresas.comfama.com/comfamab2b/es/Rutas-de-Formaci%C3%B3n-Empresarial/c/B_RUTAS_DE_FORMACION_EMPRESARIAL\r\n"
    			+ "\r\n"
    			+ "Formación para beneficiarios: https://tienda.comfama.com/comfama/es/Becas-Educaci%C3%B3n-Continua/c/B_BECAS_EDUCACION_CONTINUA\r\n"
    			+ "\r\n"
    			+ "Suscripción empresarial Ecesde & Platzi: https://servicios.cesde.edu.co/Platzi/RegistroEstudianteSuscripcionEmpresarial",
    			
    			"1. 2025-1: Desde Enero 15 hasta Marzo 10"
    			+"\r\n"
    			+"2025-2: Desde Mazo 16 hasta Julio 5"
    	};
    	return respuestaIncripciones;
    }
}
