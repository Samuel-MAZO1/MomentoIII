package operadores;

public class Pregunta {
		private int id;
		private String enunciado;
		private boolean esUtil;
		
		//Registar todas las preguntas

		public void preguntasInicial() {
			String[] preguntaIncial = {"1. Programas", 
					"2. Sedes", 
					"3. Beneficios",
					"4. Inscripciones"};
			for (int i = 0; i < preguntaIncial.length; i++) {
				System.out.println(preguntaIncial[i]);
				}
		}
		
		public void preguntasPrograma(){
			String[] preguntaPrograma = {" 0. ¿Qué programa técnico puedo estudiar siendo beneficiario de becas y/o auxilios Comfama?",
					" 1. ¿Solo puedo estudiar técnicas laborales o puedo acceder a otras ofertas académicas como beneficiario de becas Comfama? ",
					" 2. ¿Qué ofrece centro de destrezas y a qué público? ",
					" 3. ¿Qué empresas aplican para participar en el proceso de selección por destrezas?",
					" 4. ¿Para formación por destrezas puedo acceder a los servicios del Centro de destrezas?",
					" 5. ¿Cuánto tiempo dura la formación en el programa de beneficio para cesantes? ",
					" 6. ¿Qué requisitos debo cumplir para postularme a la Alianza para el empleo de jóvenes y mujeres?"
					};
			for (int i = 0; i < preguntaPrograma.length; i++) {
			System.out.println(preguntaPrograma[i]);
			}
		}
		
		public void preguntasSedes() {
			String[] preguntaSedes = {"0. ¿Puedo aplicar para cualquier sede de Cesde si soy beneficiario de becas Comfama? "};
	System.out.println(preguntaSedes[0]);
		}
		
		public void preguntasBeneficios() {
			String[] preguntaBeneficios = {" 0. ¿Los auxilios de Comfama aplican para cursos y diplomados? ",
		" 1. ¿Solo acceden los cotizantes a la formación de ley de emprendimiento o los beneficiarios podrán acceder a Ley de emprendimiento? ",
		" 2. ¿Cuánto es el beneficio económico en Ley de Emprendimiento? ",
		" 3. ¿Dónde me puedo inscribir al beneficio para cesantes? "
			};
			for (int i = 0; i < preguntaBeneficios.length; i++) {
				System.out.println(preguntaBeneficios[i]);
		}
		}
			
		public void preguntasInscripciones() {
			String[] preguntaInscripciones = {" 0. ¿Dónde me inscribo y cómo me doy cuenta del proceso? ",
					                          "1. Fechas de inscripciones:"};
			for (int i = 0; i < preguntaInscripciones.length; i++) {
				System.out.println(preguntaInscripciones[i]);
		}
		}
		}

