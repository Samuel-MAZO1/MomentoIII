package operadores;

import java.util.Scanner;

public class ChatBot {
	public static void main(String[] args) throws Exception {
		int opcion, opcionPregunta;

		Scanner sc = new Scanner(System.in);
		System.out.println("");
		sc.nextLine();
		System.out.println(
				"¡Hola, soy un chat bot generado por Mazo y Brayan relacionado con preguntas frecuentes sobre Cesde!, ");
		System.out.println("Escoge una opción sobre tu tipo de pregunta: ");
		System.out.println("");
		Pregunta pre = new Pregunta();
		Respuesta res = new Respuesta();

		// Traemos los arrays de todas las respuestas
		String[] resProm = res.respuestasPrograma();
		String[] resSedes = res.respuestasSedes();
		String[] resBene = res.respuestasBeneficio();
		String[] resInsc = res.respuestasIncripciones();

		pre.preguntasInicial();
		System.out.println("");
		opcion = sc.nextInt();
		System.out.println("");

		if (opcion == 1) {
			pre.preguntasPrograma();
			System.out.println("Escoge una opción: ");
			opcionPregunta = sc.nextInt();
			if (opcionPregunta < 0 || opcionPregunta > 6) {
				throw new Exception(" Seleccione una opción válida ");
			} else
				System.out.println(resProm[opcionPregunta]);
		}
		if (opcion == 2) {
			pre.preguntasSedes();
			System.out.println("Escoge una opción: ");
			opcionPregunta = sc.nextInt();
			if (opcionPregunta != 0) {
				throw new Exception(" Seleccione una opción válida ");
			} else
				System.out.println(resSedes[opcionPregunta]);
		}
		if (opcion == 3) {
			pre.preguntasBeneficios();
			System.out.println("Escoge una opción: ");
			opcionPregunta = sc.nextInt();
			if (opcionPregunta < 0 || opcionPregunta > 3) {
				throw new Exception(" Seleccione una opción válida ");
			} else
				System.out.println(resBene[opcionPregunta]);
		}

		if (opcion == 4) {
			pre.preguntasInscripciones();
			System.out.println("Escoge una opción: ");
			opcionPregunta = sc.nextInt();
			if (opcionPregunta < 0 || opcionPregunta > 1) {
				throw new Exception(" Seleccione una opción válida ");
			} else
				System.out.println(resInsc[opcionPregunta]);
		}

		if (opcion < 1 || opcion > 4) {
			throw new Exception(" Seleccione una opción válida ");
		}
		System.out.println("");
		System.out.println("¡Espero que le haya servido! ¿La respuesta le fue de utilidad?");

		sc.close();
	}

}
