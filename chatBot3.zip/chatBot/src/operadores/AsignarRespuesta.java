package operadores;

public class AsignarRespuesta {

}
